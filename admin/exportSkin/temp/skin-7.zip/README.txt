README 

----------------------------------
OptinSkin README for Exported Skin
 ----------------------------------
Generated on March 21, 2014, 9:45 pm 

The html content for your skin resides in the html directory, and the stylesheet in the css directory. An index.html file exists in the current directory, which you can use to check that your skin is displaying correctly. Also, you can use the index.html file to see how to embed your skin into a web page.